import { NextResponse } from "next/server";
export async function POST(req: Request) {
  try {
    const { prompt, proMode } = await req.json();
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return NextResponse.json({ error: "No API key" }, { status: 500 });
    const modelName = proMode ? "gemini-1.5-pro" : "gemini-1.5-flash";
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${apiKey}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
    });
    const data = await res.json();
    const aiText = data.candidates?.[0]?.content?.parts?.[0]?.text || "Ответ не получен.";
    return NextResponse.json({ result: aiText });
  } catch { return NextResponse.json({ error: "Error" }, { status: 500 }); }
}
