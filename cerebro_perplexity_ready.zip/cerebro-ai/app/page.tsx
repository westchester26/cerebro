'use client';
import { useState } from 'react';
import { Sparkles, Plus, Search, ArrowRight, Cpu, Layers } from 'lucide-react';
export default function Home() {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [response, setResponse] = useState('');
  const [proMode, setProMode] = useState(false);
  const handleSubmit = async () => {
    if (!prompt.trim() || isLoading) return;
    setIsLoading(true);
    try {
      const res = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt, proMode }) });
      const data = await res.json();
      setResponse(data.result || 'Ошибка');
    } catch { setResponse('Ошибка сервера'); } finally { setIsLoading(false); }
  };
  return (
    <div className="flex w-full h-screen bg-[#191A1A] text-[#E3E5E5]">
      <aside className="w-[230px] bg-[#131414] border-r border-[#2E3030] p-3 hidden md:flex flex-col justify-between">
        <div className="flex flex-col gap-5">
          <div className="flex items-center gap-2.5 px-3 py-2">
            <div className="w-7 h-7 rounded-lg bg-[#20B8CD]/20 border border-[#20B8CD]/40 flex items-center justify-center"><Sparkles className="w-4 h-4 text-[#20B8CD]" /></div>
            <span className="text-lg font-bold text-white">Cerebro</span>
          </div>
          <button onClick={()=>{setResponse('');setPrompt('');}} className="w-full px-3 py-2.5 bg-[#202222] border border-[#2E3030] rounded-xl text-sm text-white flex justify-between items-center"><span><Plus className="w-4 h-4 inline mr-2 text-[#20B8CD]"/>New Thread</span><span className="text-xs text-[#8E9393]">Ctrl K</span></button>
          <nav className="flex flex-col gap-1 text-[#8E9393]"><button className="px-3 py-2 text-sm text-white bg-[#202222] rounded-lg text-left flex items-center gap-2"><Search className="w-4 h-4 text-[#20B8CD]"/>Home</button></nav>
        </div>
      </aside>
      <main className="flex-1 flex flex-col items-center justify-center p-4 overflow-y-auto">
        <div className="max-w-[800px] w-full flex flex-col gap-4 items-center">
          {!response && <h1 className="text-3xl font-semibold text-white mb-2">Where knowledge begins</h1>}
          <div className="w-full bg-[#202222] border border-[#2E3030] rounded-2xl p-4 flex flex-col gap-3">
            <textarea value={prompt} onChange={(e)=>setPrompt(e.target.value)} placeholder="Ask anything..." rows={3} className="w-full bg-transparent text-white outline-none resize-none" />
            <div className="flex justify-between items-center border-t border-[#2E3030] pt-3">
              <button onClick={()=>setProMode(!proMode)} className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 ${proMode ? 'bg-[#20B8CD] text-black' : 'bg-[#191A1A] text-[#8E9393] border border-[#2E3030]'}`}><Cpu className="w-3.5 h-3.5"/>PRO {proMode ? 'ON' : 'OFF'}</button>
              <button onClick={handleSubmit} disabled={isLoading || !prompt.trim()} className="w-8 h-8 rounded-full bg-[#20B8CD] text-black flex items-center justify-center"><ArrowRight className="w-4 h-4"/></button>
            </div>
          </div>
          {response && <div className="w-full bg-[#202222] border border-[#2E3030] rounded-2xl p-6 text-white whitespace-pre-wrap">{response}</div>}
        </div>
      </main>
    </div>
  );
}
